AnNam Serif Trial — Version 0.910
Design: Đìzai Studio

This trial contains Regular, Bold and Italic with the Basic Latin character set only
(no Vietnamese letters, no extended symbols). It is for personal, non-commercial
testing and layout mockups that are not published. See EULA-Trial.txt.

The full family (8 styles + variable fonts, 134 Vietnamese letters, woff2)
is available under a Desktop, Web, App / Game or Logo / Brand license.

© 2026 Đìzai Studio
